以下の素材を使用しております。

-------------------------------------------------------------------------
将棋画像

このディレクトリにある将棋画像は、駒職人1氏が提供しているものです。元のデータのURLは、http://mucho.girly.jp/bona/ にあります。

-----
2ちゃんねるの将棋・チェス板・ボナンザ専用スレの駒職人1です。以下の素材は、当該スレでmind氏が開発されたCSA Shogi for Win 改良版用の駒/盤リソースを、UIの新規開発に利用しやすいであろう形式に変更したものです。駒/盤素材を一回り大きくし、アルファチャンネル付きPNG画像とすることで表示系のレイヤー化を容易にしています。

Hi, I'm Koma-Shokunin 1 in Bonanza article thead, at Shogi / Chess board in 2 Channel BBS. Here I place some Shogi pieces and gameboard images, which I originally created for CSA Shogi for Win (modified version) by Mr. Mind. I remade these images aiming at easier implementation with freeware Shogi applications by enlarging and alpha-channelling them.
-----


-------------------------------------------------------------------------
背景画像（手招きにゃんこ【青】）
http://admin.japanese-pattern.info/2015/11/09/we070073_03